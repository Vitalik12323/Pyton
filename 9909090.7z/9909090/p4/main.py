import math

# namber= 1
# while namber < 5:
#     print(f"namber = {namber}")
#     namber += 1
# print("Работа программы завершина")
# print(f"namber = {namber}")
# namber += 1
#
# number= 1
#
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершина")
# print("Работа программы завершина")
#
# number = 10
#
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершина")
# print("Работа программы завершина")
#
# number = 0
# while number < 5:
#     number += 1
#     if number == 3 :
#         break
#     print(f"number = {number}")

a=-math.pi
b =math.pi
h =math.pi/6
Y=(a/2) * math.cos(a)-math.sin(a)
while a < b:
Y = (a / 2) * math.cos(a) - math.sin(a)
